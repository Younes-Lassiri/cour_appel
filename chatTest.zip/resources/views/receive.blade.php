<div class="left message">
    <p>{{$message}}</p>
  </div>
  