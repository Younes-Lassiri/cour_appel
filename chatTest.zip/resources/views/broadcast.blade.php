<div class="right message">
    <p>{{$message}}</p>
  </div>
  