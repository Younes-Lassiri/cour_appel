<?php
    $chikaya = App\Models\Complain::get();
    $absence = App\Models\DemandeAbsence::where('employe_name', auth()->user()->admin_name)->where('status','under review')->get();
    $born = App\Models\BornDemande::where('employe_name', auth()->user()->admin_name)->where('status','under review')->get();
    $device = App\Models\DevicesDemande::where('employe_name', auth()->user()->admin_name)->where('status','under review')->get();
    $fourniture = App\Models\FournitureDemande::where('employe_name', auth()->user()->admin_name)->where('status','under review')->get();
    $imprime = App\Models\ImprimeDemande::where('employe_name', auth()->user()->admin_name)->where('status','under review')->get();
    $license = App\Models\LicenceDemande::where('employe_name', auth()->user()->admin_name)->where('status','under review')->get();
    $plastique = App\Models\PlastiqueDemande::where('employe_name', auth()->user()->admin_name)->where('status','under review')->get();
    $demandeCount = $absence->count()+$born->count()+$device->count()+$fourniture->count()+$imprime->count()+$license->count()+$plastique->count();

?>

<?php
    $absenceA = App\Models\DemandeAbsence::where('status', 'under review')->get();
    $bornA = App\Models\bornDemande::where('status', 'under review')->get();
    $deviceA = App\Models\DevicesDemande::where('status', 'under review')->get();
    $fournitureA = App\Models\FournitureDemande::where('status', 'under review')->get();
    $imprimeA = App\Models\ImprimeDemande::where('status', 'under review')->get();
    $licenseA = App\Models\LicenceDemande::where('status', 'under review')->get();
    $plastiqueA = App\Models\PlastiqueDemande::where('status', 'under review')->get();
    $demandeCountA = $absenceA->count()+$bornA->count()+$deviceA->count()+$fournitureA->count()+$imprimeA->count()+$licenseA->count()+$plastiqueA->count();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
      a{
        text-decoration: none
      }
      .dropdown-menu-end{
  background-color: #003566;
  text-align: right;
}

.dropdown-menu-end li a{
  font-size: 15px;
}

.dropdown-menu-end li{
  width: 200px;
  padding: 10px 15px;
}

.dropdown-togglee:focus{
  color: white;
}
    </style>
    
</head>
<body>
      <div class="navbarDiv" style="height: 70px">
        <div class="navbarDivOne">
            <?php if(auth()->guard()->check()): ?>
            <form action=<?php echo e(route('admin.logout')); ?> method="POST">
              <?php echo csrf_field(); ?>
              <div class="logoutDiv">
                <button type="submit"><i class='bx bx-log-out-circle ii'></i>تسجيل الخروج</button>
                <a href="<?php echo e(route('dashboard')); ?>" style="text-decoration: none"><i class='bx bxs-dashboard iiD'></i>لوحة التحكم</a>
              </div>
            </form>
            <?php endif; ?>
        </div>
        <div class="navbarDivTwo">
          <ul class="navbar-ull">
            <li><a href="<?php echo e(route('settings.show')); ?>"><i class='bx bx-cog' style='color:#ffffff'  ></i> الإعدادات</a></li>
            <?php if(auth()->user()->role === 'admin'): ?>
            
            <li><a href="<?php echo e(route('new-amploye')); ?>"><i class='bx bxs-user-plus' style='color:#ffffff'  ></i>إظافة موظف</a></li>
            <li>
              <a href="<?php echo e(route('employees.show')); ?>" style="display: flex; align-items: center; gap: 5px">
                      <i class='bx bx-envelope'></i>تدبير الموظفين
              </a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-togglee" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="display: flex; align-items: center; gap: 5px">
              <?php if($demandeCountA > 0): ?>
              <span style="color: #ffc221">(<?php echo e($demandeCountA); ?>)</span>
              <i class='bx bxs-down-arrow' style="font-size: 8px"></i>قائمة الطلبات
              <?php else: ?>
                  <i class='bx bxs-down-arrow' style="font-size: 8px"></i>
                  قائمة الطلبات
              <?php endif; ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li>
                <a class="" href="<?php echo e(route('list-licence')); ?>">
                  <?php if($licenseA->count() > 0): ?>
                  <span style="color: #ffc221">(<?php echo e($licenseA->count()); ?>) </span>طلبات رخصة إدارية
                  <?php else: ?>
                   طلبات رخصة إدارية
                  <?php endif; ?>
                </a>
              </li>
              <li><a class="" href="<?php echo e(route('list-fourniture')); ?>">
                <?php if($fournitureA->count() > 0): ?>
                <span style="color: #ffc221">(<?php echo e($fournitureA->count()); ?>) </span>طلبات أدوات المكتب
                <?php else: ?>
                    طلبات أدوات المكتب
                <?php endif; ?>
              </a></li>
              <li><a class="" href="<?php echo e(route('list-plastique')); ?>">
                <?php if($plastiqueA->count() > 0): ?>
                <span style="color: #ffc221">(<?php echo e($plastiqueA->count()); ?>) </span>طلبات الطوابع المطاطية
                <?php else: ?>
                طلبات الطوابع المطاطية
                <?php endif; ?>
              </a></li>
              <li><a href="<?php echo e(route('list-device')); ?>">
                <?php if($deviceA->count() > 0): ?>
                <span style="color: #ffc221">(<?php echo e($deviceA->count()); ?>) </span>طلبات جهاز الحاسوب و الطابعات
                <?php else: ?>
                طلبات جهاز الحاسوب و الطابعات
                <?php endif; ?>
              </a></li>
              <li><a href="<?php echo e(route('list-imprime')); ?>">
                <?php if($imprimeA->count() > 0): ?>
                <span style="color: #ffc221">(<?php echo e($imprimeA->count()); ?>) </span>طلبات المطبوعات
                <?php else: ?>
                طلبات المطبوعات
                <?php endif; ?>
              </a></li>
              <li><a href="<?php echo e(route('list-born')); ?>">
                <?php if($bornA->count() > 0): ?>
                <span style="color: #ffc221">(<?php echo e($bornA->count()); ?>) </span>طلبات الولادة
                <?php else: ?>
                طلبات الولادة
                <?php endif; ?>
              </a></li>
              <li><a href="<?php echo e(route('demande.index')); ?>">
                <?php if($absenceA->count() > 0): ?>
                <span style="color: #ffc221">(<?php echo e($absenceA->count()); ?>) </span>طلبات الغياب
                <?php else: ?>
                طلبات الغياب
                <?php endif; ?>
              </a></li>
            </ul>
          </li>
              <li>
                <a href="<?php echo e(route('listWaitingEmployees')); ?>" style="display: flex; align-items: center; gap: 5px">
                    <?php if($count > 0): ?>
                        <span style="color: #ffc221">(<?php echo e($count); ?>)</span> <i class='bx bx-envelope'></i>طلبات التسجيل
                    <?php else: ?>
                    <i class='bx bx-table'></i>
                    طلبات التسجيل
                    <?php endif; ?>
                </a>
            </li>
            <li><a href="<?php echo e(route('presence.list')); ?>"><i class='bx bxs-bell-plus' style='color:#ffffff'  ></i> لائحة الحظور</a></li>
            <?php endif; ?>
            <?php if(auth()->user()->role === 'employe'): ?>
            <li>
              <?php if($chikaya->count() > 0): ?>
              <a href=<?php echo e(route('listChikaya')); ?> style="display: flex; align-items: center; gap: 5px">
                <span style="color: #ffc221">(<?php echo e($chikaya->count()); ?>)</span>
                <i class='bx bx-line-chart'></i> تدبير الشكايات</a>
              <?php else: ?>
              <a href=<?php echo e(route('listChikaya')); ?> style="display: flex; align-items: center; gap: 5px">
                <i class='bx bx-line-chart'></i> تدبير الشكايات</a>
              <?php endif; ?>
              </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-togglee" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="display: flex; align-items: center; gap: 5px">
                <i class='bx bxs-down-arrow' style="font-size: 8px"></i>المنشورات
              </a>
              <ul class="dropdown-menu dropdown-menu-end dropdownPosts">
                <li><a href="<?php echo e(route('add-post-blade')); ?>" style="display: flex; align-items: center; gap: 5px;justify-content: end"><i class='bx bx-pencil' style='color:#ffffff'></i>إضافة منشور</a></li>
                <li><a href=<?php echo e(route('gestionPosts')); ?> style="display: flex; align-items: center; gap: 5px;justify-content: end"><i class='bx bx-line-chart'></i>إدارة المنشورات</a></li>

              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-togglee" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="display: flex; align-items: center; gap: 5px">
                <?php if($demandeCount > 0): ?>
                <span style="color: #ffc221">(<?php echo e($demandeCount); ?>)</span>
                <i class='bx bxs-down-arrow' style="font-size: 8px"></i>قائمة الطلبات
                <?php else: ?>
                    <i class='bx bxs-down-arrow' style="font-size: 8px"></i>
                    قائمة الطلبات
                <?php endif; ?>
              </a>
              <ul class="dropdown-menu dropdown-menu-end">
                <li>
                  <a class="" href="<?php echo e(route('licence.show.employe')); ?>">
                    <?php if($license->count() > 0): ?>
                    <span style="color: #ffc221">(<?php echo e($license->count()); ?>) </span>طلبات رخصة إدارية
                    <?php else: ?>
                     طلبات رخصة إدارية
                    <?php endif; ?>
                  </a>
                </li>
                <li><a class="" href="<?php echo e(route('fourniture.show.employe')); ?>">
                  <?php if($fourniture->count() > 0): ?>
                  <span style="color: #ffc221">(<?php echo e($fourniture->count()); ?>) </span>طلبات أدوات المكتب
                  <?php else: ?>
                      طلبات أدوات المكتب
                  <?php endif; ?>
                </a></li>
                <li><a class="" href="<?php echo e(route('plastique.show.employe')); ?>">
                  <?php if($plastique->count() > 0): ?>
                  <span style="color: #ffc221">(<?php echo e($plastique->count()); ?>) </span>طلبات الطوابع المطاطية
                  <?php else: ?>
                  طلبات الطوابع المطاطية
                  <?php endif; ?>
                </a></li>
                <li><a href="<?php echo e(route('list.device.employe')); ?>">
                  <?php if($device->count() > 0): ?>
                  <span style="color: #ffc221">(<?php echo e($device->count()); ?>) </span>طلبات جهاز الحاسوب و الطابعات
                  <?php else: ?>
                  طلبات جهاز الحاسوب و الطابعات
                  <?php endif; ?>
                </a></li>
                <li><a href="<?php echo e(route('list.imprime.employe')); ?>">
                  <?php if($imprime->count() > 0): ?>
                  <span style="color: #ffc221">(<?php echo e($imprime->count()); ?>) </span>طلبات المطبوعات
                  <?php else: ?>
                  طلبات المطبوعات
                  <?php endif; ?>
                </a></li>
                <li><a href="<?php echo e(route('list.born.employe')); ?>">
                  <?php if($born->count() > 0): ?>
                  <span style="color: #ffc221">(<?php echo e($born->count()); ?>) </span>طلبات الولادة
                  <?php else: ?>
                  طلبات الولادة
                  <?php endif; ?>
                </a></li>
                <li><a href="<?php echo e(route('demande.index.employe')); ?>">
                  <?php if($absence->count() > 0): ?>
                  <span style="color: #ffc221">(<?php echo e($absence->count()); ?>) </span>طلبات الغياب
                  <?php else: ?>
                  طلبات الغياب
                  <?php endif; ?>
                </a></li>
              </ul>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-togglee" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="display: flex; align-items: center; gap: 5px">
                <i class='bx bxs-down-arrow' style="font-size: 11px"></i>ملئ  طلب
              </a>
              <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="" href="<?php echo e(route('licence.show')); ?>">طلب رخصة إدارية</a></li>
                <li><a class="" href="<?php echo e(route('fourniture.show')); ?>">طلب أدوات المكتب</a></li>
                <li><a class="" href="<?php echo e(route('plastique.show')); ?>">طلب الطوابع المطاطية</a></li>
                <li><a href="<?php echo e(route('device.show')); ?>">طلب جهاز الحاسوب و الطابعات</a></li>
                <li><a href="<?php echo e(route('imprime.show')); ?>">طلب المطبوعات</a></li>
                <li><a href="<?php echo e(route('born.show')); ?>">طلب الولادة</a></li>
                <li><a href=<?php echo e(route('demande.show')); ?>>طلب الغياب</a></li>
              </ul>
            </li>

            <li><a href=<?php echo e(route('message.gestion')); ?> style="display: flex; align-items: center; gap: 5px"><i class='bx bx-table'></i>تدبير الواردات</a></li>            
            <li><a href=<?php echo e(route('message.index')); ?> style="display: flex; align-items: center; gap: 5px"><i class='bx bx-envelope'></i>لائحة الواردات</a></li>
            <li><a href=<?php echo e(route('message.add')); ?> style="display: flex; align-items: center; gap: 5px"><i class='bx bx-add-to-queue'></i>إظافة واردة</a></li>
            <?php endif; ?>
            <li><a href="/"><i class='bx bx-home' style='color:#003566;background: #ffc300; padding: 14px 14px; border-radius: 5px'  ></i></a></li>
            
          </ul>
      </div>
      </div>
</body>
</html>


<?php /**PATH C:\chatApp\chatTest\resources\views/components/admin_navbar.blade.php ENDPATH**/ ?>