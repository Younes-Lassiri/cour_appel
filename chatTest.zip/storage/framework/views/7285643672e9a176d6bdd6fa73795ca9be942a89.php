<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/master.css">
    <link rel="stylesheet" href="../css/framework.css">
    <link rel="stylesheet" href="../css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com"/>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;500&display=swap" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
    <?php
        $data = [
            [
                "id" => 1,
                "tag" => "522AAR0",
                "description" => "Equipement",
                "type" => "equipements"
            ],
            [
                "id" => 2,
                "tag" => "501AAD03",
                "description" => "Tour finale",
                "type" => "echangeur"
            ],
            [
                "id" => 3,
                "tag" => "501AAD02",
                "description" => "Tour de sechage",
                "type" => "Tour"
            ]
        ];


    ?>
    <input type="text" name="" id="tagInput" placeholder="Entre le N° d'équipement">
    <button onclick="search()">Recherche</button>
    <table border="1">
        <tr>
            <th>Id</th>
            <th>Tag</th>
            <th>Description</th>
            <th>Type</th>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr class="allRows">
                <td><?php echo e($item['id']); ?></td>
                <td><?php echo e($item['tag']); ?></td>
                <td><?php echo e($item['description']); ?></td>
                <td><?php echo e($item['type']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <script>
        function search() {
            var tag = document.getElementById('tagInput').value.trim();
            var rows = document.getElementsByClassName('allRows');
            for (var i = 0; i < rows.length; i++) {
                var row = rows[i];
                var tagCell = row.getElementsByTagName('td')[1];
                if (tagCell.textContent.trim().includes(tag)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        }
    </script>
</body>
</html><?php /**PATH C:\chatApp\chatTest\resources\views/assist.blade.php ENDPATH**/ ?>