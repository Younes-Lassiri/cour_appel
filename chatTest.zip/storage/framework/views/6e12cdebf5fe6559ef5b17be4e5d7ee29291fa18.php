<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" href="/img/icon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>نافذة الحق</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://cdn.lordicon.com/lordicon.js"></script>
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.landing-section_head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('landing-section_head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user_navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user_navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <input type="hidden" id="title" value="<?php echo e($categorie === 'news' ? 'قسم الأخبار' : 'قسم البلاغات'); ?>">
    <div class="categorieSection">
        <div class="categorieSectionOne">
            <nav style="" aria-label="breadcrumb" class="breadCumb">
                <ol class="breadcrumb" style="padding: 14px 0 0 0">
                  <li class="breadcrumb-item" style="color: #809AB3;font-style: normal;font-weight: bold"><?php if($categorie === 'news'): ?>
                    الأخبار
                  <?php else: ?>
                  بلاغات
                  <?php endif; ?></li>
                  <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('home')); ?>"><i class='bx bx-home' style='color:#809AB3; padding: 2px 2px; border-radius: 5px'  ></i></a></li>
                </ol>
              </nav>
        </div>
        <div class="categorieSectionTwo">
            <div class="categorieSectionTwoOne">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="categorieSectionTwoOneOne">
                        <div class="categorieSectionTwoOneOneOne"><img src="<?php echo e(asset($post->images[0]->image)); ?>" alt=""></div>
                        <div class="categorieSectionTwoOneOneTwo"><?php echo e($post->title); ?></div>
                        <div class="categorieSectionTwoOneOneThree">
                            <?php
                                $words = explode(' ', $post->description);
                                $limitedWords = implode(' ', array_slice($words, 0, 15));
                                print($limitedWords);
                            ?>
                            <span style="color: #ffbc2b">[</span>...<span style="color: #ffbc2b">]</span>
                        </div>
                        <div class="categorieSectionTwoOneOneFour">
                            <?php
                                $postMonth = intval(explode('-', explode(' ', $post->created_at)[0])[1]);
                                $monthAbbreviation = isset($months[$postMonth - 1]) ? $months[$postMonth - 1] : '';
                            ?>
                            <div class="categorieSectionTwoOneOneFourOne"><a href="<?php echo e(route('detailPost', [explode(' ',$post->created_at)[0], $post->id, str_replace(' ', '-', $post->title)])); ?>" style="text-decoration: none"><button><span style="color: #003566;font-weight: 600">←</span> إقرأ المزيد</button></a></div>
                            <div class="categorieSectionTwoOneOneFourTwo"><p><span style="color: #003566;"><?php echo e($monthAbbreviation); ?></span><?php echo e(explode('-', explode(' ', $post->created_at)[0])[0]); ?> <?php echo e(explode('-', explode(' ', $post->created_at)[0])[2]); ?><i class='bx bxs-time-five' style='color:#003566'  ></i></p></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="detailPost-sectionThree">
                <div class="detailPost-sectionThreeOne <?php if($categorie === 'news'): ?> categorieVisited <?php endif; ?>"><a href="<?php echo e(route('categorie', 'news')); ?>">الأخبار</a></div>
                <div class="detailPost-sectionThreeOne <?php if($categorie === 'report'): ?> categorieVisited <?php endif; ?>""><a href="<?php echo e(route('categorie', 'report')); ?>">بلاغات</a></div>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            let title = document.querySelector('#title').value;
            document.title = document.title + ' - ' + title;
        });
    </script>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.foo_ter','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('foo_ter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</body>
</html><?php /**PATH C:\chatApp\chatTest\resources\views/post-galerie.blade.php ENDPATH**/ ?>