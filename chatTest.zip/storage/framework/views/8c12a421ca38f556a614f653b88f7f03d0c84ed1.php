<div class="left message">
    <p><?php echo e($message); ?></p>
  </div>
  <?php /**PATH C:\chatApp\chatTest\resources\views/receive.blade.php ENDPATH**/ ?>